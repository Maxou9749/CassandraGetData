shinyUI(fluidPage(
  titlePanel("Edit .Renvion file"),
  helpText("Changes to the table will be saved to the source file by pressing the button save. 
           Please reload R after saving your modifications."),
  rHandsontableOutput("hot"),
  br(),
  # comment lines below if action button is used to commit changes
  actionButton("saveBtn", "Save"),
  actionButton("quitBtn", "Quit")
))