shinyServer(function(input, output, session) {
  fname <- paste0(Sys.getenv("HOME"),"/",".Renviron")
  
  # uncomment lines below if action button is used to commit changes
  values = list()
  setHot = function(x) values[["hot"]] <<- x
  
  # comment lines below if action button is used to commit changes
  # values = reactiveValues()
  # setHot = function(x) values[["hot"]] = x
  
  observe({
    input$saveBtn
    
    if (!is.null(values[["hot"]])) {
      write.table(values[["hot"]], fname,sep = '=',col.names = F, row.names = F, quote = F)
      cat(paste("Properties updated into ",fname,"\n"))
    }
  })
  
  output$hot = renderRHandsontable({
    if (!is.null(input$hot)) {
      DF = hot_to_r(input$hot)
    } else {
      .IfNotExistCreateREnviron()
      DF = read.table(fname,sep='=',col.names = c("var","value"),stringsAsFactors = F)
    }
    
    setHot(DF)
    rhandsontable(DF) %>%
      hot_table(highlightCol = TRUE, highlightRow = TRUE) %>%
      hot_col("var", readOnly = TRUE)
  })
  
  observe({
    if(input$quitBtn > 0){
      stopApp()
    }
  })
})