library(rLE2P)
if("rhandsontable" %in% rownames(installed.packages()) == FALSE) {
  if("devtools" %in% rownames(installed.packages()) == FALSE) 
    install.packages("devtools")
  devtools::install_github("jrowen/rhandsontable")
}
library(rhandsontable)