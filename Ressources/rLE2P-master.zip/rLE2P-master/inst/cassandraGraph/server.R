shinyServer(function(input, output, session) {
  
  # Functions ---------------------------------------------------------------
  
  getData <- function(input, iUiCpt = NULL, returnMissing = FALSE){
    captorList <- input[[paste0("cptName",iUiCpt)]]
    if(is.null(input$dateSelect) | is.null(input$trId) | is.null(captorList) | is.null(input$recul)) return()
    start <- paste(as.Date(input$dateSelect)-input$recul+1,"00:00:00")
    end   <- paste(input$dateSelect,"23:59:59")
    cassData <- CassandraGetData(input$trId,captorList,start,end)
    if (is.null(cassData)) return()
    if (length(captorList)>1){
      data <- xts(x = cassData[[captorList[1]]]$value, order.by = as.POSIXct(cassData[[captorList[1]]]$date))
      for (i in captorList[-1])
        data <- cbind(data, xts(x = cassData[[i]]$value, order.by = as.POSIXct(cassData[[i]]$date)))
    } else {
      data <- xts(x = cassData$value, order.by = as.POSIXct(cassData$date))
    }
    if (returnMissing){
      p <- periodicity(data)
      fullDate <- seq.POSIXt(p$start, p$end, p$units)
      data <- cbind(xts(order.by = fullDate), data)
    }
    colnames(data) <- captorList
    return(data)
  }

  get_plot_output_list <- function(input_n) {
    if (input_n<1) return()
    plot_output_list <- lapply(1:input_n, function(i) {
      plotname <- paste("dygraph", i, sep="")
      plot_output_object <- dygraphOutput(plotname)
      plot_output_object <- renderDygraph({
        X <- getData(input, iUiCpt = i, returnMissing = input$checkboxNa)
        if (is.null(X) | is.character(X)) return()
        myPlot <- dygraph(X, group = "lead") %>% dyRangeSelector() 
        if (input$checkboxPoint) 
          myPlot <- myPlot %>% dySeries(drawPoints = T, pointSize = 1, strokeWidth = 0)
        myPlot 
      })
    })
    
    do.call(tagList, plot_output_list) # needed to display properly.
    return(plot_output_list)
  }
  
  # Reactives ---------------------------------------------------------------
  
  tr <- reactive({
    input$reloadTrBtn
    data <- CassandraGetTransactionList()[,c("transaction_id","name")]
    data <- data[order(data[,2]),]
    outp <- as.list(data[,1])
    names(outp) <- data[,2]
    outp
  })
  
  cpt <- reactive({
    input$reloadCptBtn
    if (is.null(input$trId)) return()
    CassandraGetSensorFromTransaction(input$trId, onlyWithData = T, rows = 1000) %>%  sort
  })
  
  bornes <- reactive({
    if (is.null(input$trId) | is.null (input$cptName)) return()
    met <- CassandraGetMetadata(input$trId, input$cptName)
    if (is.null(met$date_system_timeStart)) return()    
    list(
      min = met$date_system_timeStart %>% substr(1,10) %>% as.Date, 
      max = met$date_system_timeEnd %>% substr(1,10) %>% as.Date
    )
  })
  
  
  nCpt <- reactive({
    input$addCpt - input$delCpt
  })
  
  
  # Render UI ---------------------------------------------------------------
  
  output$uiTr <-renderUI({
    selectInput('trId', NULL, tr())
  })
  
  output$uiCpt <-renderUI({
    values <- cpt()
    if(length(values) == 0)
      return(strong("No captor for this transaction."))
    selectInput('cptName', NULL, values)
  })

  output$supUiCpt <- renderUI(({
    values <- cpt()
    if(length(values) == 0)
      return(strong("No captor for this transaction."))
    if (nCpt() < 1) return()
    lapply(1:nCpt(), function(i) {
      fluidRow(
        column(width = 8,
               selectInput(paste0("cptName", i), NULL, values, multiple = T, selected = values[i+1])
        )
      )
    })
  }))
  
  output$uiYear <-renderUI({
    b <- bornes()
    if (is.null(b)) return()
    sliderInput('dateSelect',label = "Last dates :", min=b$min, max=b$max, value= b$max, width = "100%")
  })
  
  # render Dygraph ----------------------------------------------------------
  
  output$dygraph <- renderDygraph({
    X <- getData(input, returnMissing = input$checkboxNa)
    if (is.null(X) | is.character(X)) return()
    myPlot <- dygraph(X, group = "lead") %>% dyRangeSelector() 
    if (input$checkboxPoint) 
      myPlot <- myPlot %>% 
      dySeries(drawPoints = T, pointSize = 1, strokeWidth = 0)
    myPlot 
  })
  
  # Observes ----------------------------------------------------------------  
  
  observe({
    if(nCpt() <1) return()
    output$plots <- renderUI({get_plot_output_list(nCpt())})
  })
  
  # Quit button
  observe({ if(input$quitBtn > 0) stopApp() })
  
})