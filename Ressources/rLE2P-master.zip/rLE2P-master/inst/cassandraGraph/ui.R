shinyUI(
  pageWithSidebar(
    headerPanel('rLE2P Cassandra Graph Apps', windowTitle = 'Cassandra Graph'),
    sidebarPanel(
      
      tags$head(tags$style(
        type = "text/css",
        "#loadmessage {position: fixed;top: 0px;left: 0px;
        width: 100%;padding: 5px 0px 5px 0px;
        text-align: center; font-weight: bold;
        font-size: 100%; color: #FFFFFF;
        background-color: #428BCA;
        z-index: 105;
        }"
      )),
      
      conditionalPanel(condition = "$('html').hasClass('shiny-busy')",
                       tags$div("Loading...",id = "loadmessage")),
      
      # Slider CSS 
      tags$style(HTML(".js-irs-0 .irs-bar-edge, .js-irs-0 .irs-bar {background: transparent; border: transparent}")),
      tags$style(HTML(".js-irs-1 .irs-bar-edge, .js-irs-1 .irs-bar {background: transparent; border: transparent}")),
      
      # Form 
      strong("Select your transaction :"),
      fluidRow(
        column(width = 8, uiOutput("uiTr")),
        column(width = 1, align="center", 
                actionButton("reloadTrBtn", "", icon = icon("refresh"))
        )
        # column(width = 1, align="center", 
        #        actionButton("addTr", NULL, icon = icon("fa fa-plus"))
        # )
      ),
      strong("Select your captor :"),
      fluidRow(
        column(width = 8, uiOutput("uiCpt")),
        column(width = 1, align="center", 
               actionButton("reloadCptBtn", "", icon = icon("refresh"))
        ),
        column(width = 1, align="center", 
               actionButton("addCpt", NULL, icon = icon("plus"))
        ),
        column(width = 1, align="left", 
               actionButton("delCpt", NULL, icon = icon("minus"))
        )
      ),
      uiOutput('supUiCpt'),
      strong('Options :'),
      fluidRow(
        column(width = 4, br(),p('Interval Range Size :')),
        column(width = 8, sliderInput('recul', NULL, 1, 31, 10, ticks = F))
      ),
      fluidRow(
        column(width = 6, checkboxInput("checkboxNa", label = "Compute NA?", value = TRUE)),
        column(width = 6, checkboxInput("checkboxPoint", label = "Dots only?", value = FALSE)
        )
      ),
      br(),
      fluidRow(
        column(width = 12, align = 'right',
               actionButton("quitBtn", "Quit", icon = icon("sign-out"))
        )
      )
    ),
    mainPanel(
      uiOutput("uiYear"),
      dygraphOutput("dygraph"),
      uiOutput("plots")
    )
  )
)