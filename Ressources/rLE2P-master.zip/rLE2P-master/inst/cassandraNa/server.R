shinyServer(function(input, output, session) {
  
  # Reactives ---------------------------------------------------------------
  
  tr <- reactive({
    input$reloadTrBtn
    data <- CassandraGetTransactionList()[,c("transaction_id","name")]
    bool <- data$transaction_id %in% trExculdeList
    data <- data[!bool, ]
    data <- data[order(data$name),]
    output <- as.list(data$transaction_id)
    names(output) <- data$name
    return(output)
  })
  
  cpt <- eventReactive({
    input$reloadCptBtn; input$idTr},{
      if (is.null(input$idTr)) return()
      CassandraGetSensorFromTransaction(input$idTr, onlyWithData = T, rows = 1000) %>%  sort
    }
  )
  
  boolReCompute <- eventReactive({input$reComputeBtn},{
    idCpt <- isolate(input$idCpt)
    if (is.null(idCpt)) return(FALSE)
    idTr  <- isolate(input$idTr)
    # print("Re compute all set")
    dirname  <- paste0("~/rLE2P_saves/cassandraNa_saves/", idTr,'/')
    filename <- paste0(dirname, idTr, '_', idCpt, '.RData')
    cassSensorNa <- CassandraGetSensorNa(idTr, idCpt)
    save(cassSensorNa, file = filename)
    return(TRUE)
  }, ignoreNULL = FALSE)
  
  boolComplete <- eventReactive({input$completeBtn},{
    idTr  <- isolate(input$idTr)
    if (is.null(idTr)) return(FALSE)
    dirname  <- paste0("~/rLE2P_saves/cassandraNa_saves/", idTr,'/')
    allFiles <- list.files(dirname, full.names = T)
    for (f in allFiles){
      load(f)
      # print(paste("Complete known data :", f))
      cassSensorNaNew <- CassandraGetSensorNa(cassSensorNa$idTransaction, cassSensorNa$idSensor, 
                                              dateStart = as.Date(cassSensorNa$timeEnd))
      n <- nrow(cassSensorNa$nNaByDay)
      cassSensorNa <- list(
        nNaByDay = rbind(cassSensorNa$nNaByDay[-n, ], cassSensorNaNew$nNaByDay),
        nYear = cassSensorNa$nYear + cassSensorNaNew$nYear - 1,
        idTransaction =  idTr,
        idSensor =  cassSensorNa$idSensor,
        timeStart = cassSensorNa$timeStart,
        timeEnd = cassSensorNaNew$timeEnd,
        now = Sys.time(),
        executionTime = cassSensorNaNew$executionTime
      )
      save(cassSensorNa, file = f)
    }
    return(TRUE)
  }, ignoreNULL = FALSE)
  
  
  getData <- reactive({
    
    boolReCompute()
    boolComplete()
    idCpt <- input$idCpt
    idTr  <- isolate(input$idTr) # no reload is modified
    if (is.null(idTr) || is.null(idCpt)) return()
    
    dirname  <- paste0("~/rLE2P_saves/cassandraNa_saves/", idTr,'/')
    filename <- paste0(dirname, idTr, '_', idCpt, '.RData')
    
    if (file.exists(filename)){
      # print("Load data")
      load(filename)
    } else {
      # print("First time computation then Load")
      cassSensorNa <- CassandraGetSensorNa(idTr, idCpt)
      dir.create(dirname, showWarnings = F, recursive = T)
      save(cassSensorNa, file = filename)
    }
    return(cassSensorNa)    
  })
  
  # Render UI ---------------------------------------------------------------
  
  output$uiTr <-renderUI({
    selectInput('idTr', NULL, tr())
  })
  
  output$uiCpt <-renderUI({
    values <- cpt()
    if(length(values) == 0) return(NULL)
    selectInput('idCpt', NULL, values)
  })
  
  # outputs -----------------------------------------------------------------
  
  output$view <-  renderGvis({
    
    thisData <- getData()
    if (is.null(thisData)) return()
    
    gvisCalendar(
      thisData$nNaByDay, datevar="date", numvar="nNA", 
      options = list(
        width= "100%", 
        height = 40 + 180 * thisData$nYear, 
        colorAxis=  "{colors:['#2DD93D','#F2B705', '#F29F05', '#BF3604', '#D9190F'], values:['0', '1', '20', '99', '1440']}",
        calendar = "{cellSize:20, focusedCellColor:{stroke:'red'}, monthLabel:{fontSize:12}}"),
      chartid = paste0(thisData$idTransaction, '$', thisData$idSensor)
    )
  })
  
  output$infos <- renderUI({
    thisData <- getData()
    if (is.null(thisData)) return()
    execT <- paste(round(as.double(thisData$executionTime, units = 'secs'), 1), 'secs')
    labels <- c("transaction id", "sensor id", "time start", "time end", 
                "number of year", "last execution", "last execution time")
    values <- c(thisData$idTransaction, thisData$idSensor, as.character(thisData$timeStart),
                as.character(thisData$timeEnd), thisData$nYear, as.character(thisData$now), execT)
    htmlLabels <- paste0('<tr><td><b><i>', labels , '</i></b></td>')
    htmlValues <- paste0('<td>', values, '</td></tr>')
    htmlTable  <- paste0('<table class="table table-striped">', paste0(htmlLabels, htmlValues, collapse = ''), '</table>')
    HTML(htmlTable)
  })
  
  
  output$report <- downloadHandler(
    filename = "report.html",
    content = function(file) {
      # Copy the report file to a temporary directory before processing it, in
      # case we don't have write permissions to the current working dir (which
      # can happen when deployed).
      tempReport <- file.path(tempdir(), "report.Rmd")
      file.copy("report.Rmd", tempReport, overwrite = TRUE)
      
      # Set up parameters to pass to Rmd document
      params <- list(idTransaction = input$idTr)
      
      # Knit the document, passing in the `params` list, and eval it in a
      # child of the global environment (this isolates the code in the document
      # from the code in this app).
      rmarkdown::render(tempReport, output_file = file,
                        params = params,
                        envir = new.env(parent = globalenv())
      )
    }
  )
  
  # Observes ----------------------------------------------------------------  
  
  # Quit button
  observe({ if(input$quitBtn > 0) stopApp() })
  
})
