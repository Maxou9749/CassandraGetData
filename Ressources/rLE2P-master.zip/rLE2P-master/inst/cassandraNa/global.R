library(rLE2P)
library(shiny)
library(xts)
library(googleVis)
library(dygraphs)

# No Qi data (seconde) & Giovanni (test)
trExculdeList <- c(1487856319, 1489063001)


