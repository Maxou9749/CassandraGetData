shinyUI(
  pageWithSidebar(
    headerPanel('rLE2P Cassandra NA Apps', windowTitle = 'Cassandra NA'),
    sidebarPanel(
      
      tags$head(tags$style(
        type = "text/css",
        "#loadmessage {position: fixed;top: 0px;left: 0px;
        width: 100%;padding: 5px 0px 5px 0px;
        text-align: center; font-weight: bold;
        font-size: 100%; color: #FFFFFF;
        background-color: #428BCA;
        z-index: 105;
        }"
      )),
      
      conditionalPanel(condition = "$('html').hasClass('shiny-busy')",
                       tags$div("Loading...",id = "loadmessage")),
      
      # Slider CSS 
      tags$style(HTML(".js-irs-0 .irs-bar-edge, .js-irs-0 .irs-bar {background: transparent; border: transparent}")),
      tags$style(HTML(".js-irs-1 .irs-bar-edge, .js-irs-1 .irs-bar {background: transparent; border: transparent}")),
      
      # Form 
      strong("Select your transaction :"),
      fluidRow(
        column(width = 10, uiOutput("uiTr")),
        column(width = 1, align="center", 
               actionButton("reloadTrBtn", "", icon = icon("refresh"))
        )
      ),
      strong("Select your captor :"),
      fluidRow(
        column(width = 10, uiOutput("uiCpt")),
        column(width = 1, align="center", 
               actionButton("reloadCptBtn", "", icon = icon("refresh"))
        )
      ),
      strong("Infos :"), p(),
      htmlOutput("infos"),
      strong("Actions :"), 
      p(), fluidRow(
        column(width = 4, align = 'center',
               actionButton("completeBtn", "Complete dates (All)", icon = icon("plus"))
        ),
        column(width = 4, align = 'center',
               actionButton("reComputeBtn", "Re-eval all dates (1)", icon = icon("refresh"))
        ),
        column(width = 4, align = 'center',
               downloadButton("report", "Generate report")
        )), br(),
      p(strong('(All)'),'will complete data for all known data, ', strong('(1)'), 'will re-eval the whole data only for the selected sensor'),
      p('Report can be long to be generated.'),
      fluidRow(
        column(width = 12, align = 'right',
               actionButton("quitBtn", "Quit", icon = icon("sign-out"))
        )
      )
    ), 
    mainPanel(
      htmlOutput("view")
    )
  )
)