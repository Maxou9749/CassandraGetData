shinyServer(
  function(input, output, session) {
    
    # Select of the transaction after selection of source
    output$uiTransaction <-renderUI({
      values <- GetInfoMetadata()$transactionName
      selectInput('transactionName', 'Select your transaction :', sort(values))
    })
    
    # Select of the captor after selection of transaction
    output$uiName <-renderUI(expr = {
      if(is.null(input$transactionName)) return()
      values <- {
        query <- paste('dataType=="xts" & transactionName=="', input$transactionName ,'"',sep='')
        uuid <- GetUuidFromQuery(query,T)
        if(is.null(uuid)) return(NULL)
        metaName <- sapply(uuid, function(ele,bank){bank[[ele]][['dataName']]}, bank = .rLE2P$bank)
        names(metaName) <- NULL
        metaName
      }
      if(length(values)==0)
        return(strong("No captor for this transaction."))
      selectInput('name', 'Select your captor :', sort(values))
    })
    
    # Select Dates
    output$uiYear <-renderUI(expr = {
      if(is.null(input$transactionName) | is.null(input$name)) return()
      values <- {
        query <- paste0('dataType=="xts" & transactionName=="', input$transactionName ,'" & dataName=="', input$name,'"')
        uuid <- GetUuidFromQuery(query,T)
        if(is.null(uuid)) return(NULL)
        met <- GetInfoMetadata(uuid)
        minDate <- as.Date(as.POSIXct(as.numeric(met["timeStart"]),origin="1970-01-01"))
        maxDate <- as.Date(as.POSIXct(as.numeric(met["timeEnd"]),origin="1970-01-01"))
        start <-maxDate-10
        if (met["timeScale"]=="daily")
          start <-minDate
      }
      sliderInput('dateSelect',label = "Last dates :", min=minDate, max=maxDate, value= maxDate, width = "100%")
    })
    
    # Reach data
    selectedData <- eventReactive({input$dateSelect;input$transactionName;input$recul;input$name},{
      if(is.null(input$dateSelect) | is.null(input$transactionName) | is.null(input$name) | is.null(input$recul))
        return(NULL)
      start <- paste(as.Date(input$dateSelect)-input$recul+1,"00:00:00")
      end   <- paste(input$dateSelect,"23:59:59")
      
      query <- paste('dataType=="xts" & dataName=="', input$name, '" & transactionName=="', input$transactionName ,'"',sep='')
      uuid <- GetUuidFromQuery(query,T)
      if (is.null(uuid)) return(NULL)
      load(paste0(Sys.getenv("rLE2P_working_directory"),'/data/',uuid,'.RData'), envir = .GlobalEnv)
      where <- paste(start,end,sep='/')
      Xt[where]
    })
    
    # Plot output
    output$dygraph <- renderDygraph({
      X <- selectedData()
      if (is.null(X) | is.character(X)) return(NULL)
      title <- paste(input$dataSource,'-',input$transactionName,'-',input$name)
      myPlot <- dygraph(X, main = title) %>% dyRangeSelector()
      if (input$checkboxPoint) myPlot <- myPlot %>% dySeries(drawPoints = T, pointSize = 1, strokeWidth = 0)
      myPlot 
    })
    
    # Quit button
    observe({
      if(input$quitBtn > 0){
        stopApp()
      }
    })
    
  })