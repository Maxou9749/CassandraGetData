shinyUI(
  pageWithSidebar(
    headerPanel('rLE2P Bank Graph Apps'),
    sidebarPanel(

      # Loading bar
      tags$head(tags$style(
        type = "text/css",
        "#loadmessage {position: fixed;top: 0px;left: 0px;
        width: 100%;padding: 5px 0px 5px 0px;
        text-align: center; font-weight: bold;
        font-size: 100%; color: #FFFFFF;
        background-color: #428BCA;
        z-index: 105;
        }"
      )),

      conditionalPanel(condition = "$('html').hasClass('shiny-busy')",
                       tags$div("Loading...",id = "loadmessage")),
      
      # Slider CSS 
      tags$style(HTML(".js-irs-0 .irs-bar-edge, .js-irs-0 .irs-bar {background: transparent; border: transparent}")),
      tags$style(HTML(".js-irs-1 .irs-bar-edge, .js-irs-1 .irs-bar {background: transparent; border: transparent}")),
      
      # Form 
      uiOutput("uiTransaction"),
      uiOutput("uiName"),
      strong('Options :'),
      checkboxInput("checkboxPoint", label = "Only Points ?", value = FALSE),
      sliderInput('recul', h5('Days Interval Range Size :'), 1, 31, 10, ticks = F),
      br(),
      actionButton("quitBtn", "Quit")
    ),
    mainPanel(
      dygraphOutput("dygraph"),
      br(),
      uiOutput("uiYear")
    )
  ))