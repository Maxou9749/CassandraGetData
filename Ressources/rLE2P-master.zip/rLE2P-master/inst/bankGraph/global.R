library(shiny)
library(dygraphs)
library(rLE2P)
.IsContextSet()

#' Change date where actualisation of captor
#' to event the change of date because reload
#' data only if date where modifies 
valueResetDate <- FALSE