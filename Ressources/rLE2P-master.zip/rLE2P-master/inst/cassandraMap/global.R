library(shiny)
library(leaflet)
library(rLE2P)
library(dygraphs)
library(xts)
library(shinyWidgets)

getMeta <- function(){
  solrQuery <- "q=trans_double_locality_longitude:*+AND+sensor_id:ghost&rows=0&wt=json&facet=true&facet.field=transaction_id&facet.mincount=1"
  transaction <- CassandraGetSolrQuery(query = solrQuery)$facet_counts$facet_fields$transaction_id
  transaction <- transaction[seq(1,length(transaction),2)]
  meta <- lapply(transaction, CassandraGetMetadata, idSensor = 'ghost', 
                 fl='transaction_id,trans_text_locality_name,trans_double_locality_latitude,trans_double_locality_longitude')
  do.call(rbind.data.frame, meta)
}

getData <- function(idTransaction){
  idTransaction <- as.character(idTransaction)
  solrQuery <- paste0('q=transaction_id:',idTransaction,'+AND+text_application_captor:("DHI","GHI")+AND+date_system_timeEnd:*&rows=2&wt=json')
  myDoc <- CassandraGetSolrQuery(query = solrQuery)$response$docs
  if (is.null(myDoc$date_system_timeEnd)) return(NULL)
  myDate <- max(as.Date(myDoc$date_system_timeEnd))
  CassandraGetData(idTransaction, myDoc$sensor_id,paste(myDate,"00:00:00"),paste(myDate,"23:59:59"))
}

spn1Icon <- makeIcon(
  iconUrl = "./www/img/spn1.png",
  iconWidth = 45, iconAnchorX = 22, iconAnchorY = 22
)