bootstrapPage(
  tags$head(includeCSS("./www/styles.css")),
  tags$style(type = "text/css", "html, body {width:100%;height:100%}"),
  leafletOutput("mymap", width = "100%", height = "100%"),
  absolutePanel(
    fixed = T, top = 15, left = 50, right = "auto", bottom = "auto",  height = "auto",  width = "80%",
    dropdownButton(
      status = "primary", icon = icon("area-chart"), width = "100%",
      strong("Select an SPN1, show last data :"),
      dygraphOutput("graph", height = "500px")
    )
  ), 
  absolutePanel(
    fixed = T, bottom = 10, left = 10,  
    switchInput(inputId = "grouped", label = "Grouped", value = TRUE), br(),
    switchInput(inputId = "satellite", label = "Satellite", value = FALSE)
  ), 
  absolutePanel(
    fixed = T, top = 10, right = 10,  
    actionButton("reload", label = "", icon = icon("refresh"))
  )
)