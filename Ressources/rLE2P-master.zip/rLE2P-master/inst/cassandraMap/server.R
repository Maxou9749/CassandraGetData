shinyServer(function(input, output, session) {
  output$mymap <- renderLeaflet({
    meta <- getMeta()
    leaflet()  %>% addTiles() %>% addMarkers(
      lng   = meta$trans_double_locality_longitude, 
      lat   = meta$trans_double_locality_latitude, 
      popup = meta$trans_text_locality_name,
      layerId = meta$transaction_id,
      icon = spn1Icon,
      clusterOptions = markerClusterOptions()
    ) %>% setView(lng = 55.526490 , lat = -21.130679, zoom = 10)
  })
  
  observe(leafletProxy("mymap") %>% clearTiles() %>% addProviderTiles(if(!input$satellite){"OpenStreetMap.Mapnik"} else {"Esri.WorldImagery"}))
  
  observeEvent({input$reload; input$grouped}, {
    meta <- getMeta()
    leafletProxy("mymap") %>% clearMarkers() %>% clearMarkerClusters() %>% addMarkers(
      lng   = meta$trans_double_locality_longitude, 
      lat   = meta$trans_double_locality_latitude, 
      popup = meta$trans_text_locality_name,
      layerId = meta$transaction_id,
      icon = spn1Icon,
      clusterOptions = if(input$grouped) markerClusterOptions() else NULL
    )
  })
  
  observe({
    click <- input$mymap_marker_click
    if(is.null(click)) return()
    myData <- getData(click$id)
    if (is.null(myData)) return()
    dyData <- cbind(
      xts(myData[[1]]$value, order.by = as.POSIXct(myData[[1]]$date)),
      xts(myData[[2]]$value, order.by = as.POSIXct(myData[[2]]$date))
    )
    names(dyData) <- names(myData)
    output$graph <- renderDygraph(dyData %>% dygraph()) 
  })
})