#' Create de new .Renviron datafile
#'
#' Create a .Renviron file containing all properties for connexion et working.
#' Present in properties :
#'   - MySQL Server config for RCI-GS Database,
#'   - Rest Service host for Cassandra Database,
#'   - Working path for data storage
#'    
#' @return NULL
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' .IfNotExistCreateREnviron()
#' }
#'
#' @export
#'
.IfNotExistCreateREnviron = function(){
  
  # .Renviron Path and file 
  fileREnviron <- paste0(Sys.getenv("HOME"),"/",".Renviron")
  
  if (!file.exists(fileREnviron)){
    
    # Param Defaults values
    value <- c("rLE2P_mysql_host=le2p-mysql.univ.run",
               "rLE2P_mysql_user=username",
               "rLE2P_mysql_password=password",
               "rLE2P_mysql_dbname=rcigs_bdd",
               "rLE2P_restHost=https://geosun.univ-reunion.fr",
               "rLE2P_restUserPwd=username:password",
               "rLE2P_working_directory=~")
    rEnvironNew <- data.frame( value, stringsAsFactors = F)
    
    # Write File 
    write.table(rEnvironNew, file = fileREnviron, sep = '=', col.names = F, row.names = F, quote = F)
    
  }
}