#' Create new metadata banque 
#'
#' Create (and erase old one) metadata bank.
#' 
#' @param reset (bool) If true, reset old metadata bank.
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' NewMetadataBank(reset=TRUE)
#' }
#' 
#' @seealso \code{\link{WriteMetadataBank}, 
#' \link{DeleteMetadataBank}, \link{ExistMetadataBank}}
#' \link{GetInfoMetadata}
#' 
NewMetadataBank = function(reset = FALSE){
  
  #! Check if there is an existing bank
  danger <- exists("bank") | file.exists('./data/bank.RData')
  if (!danger | reset){
    
    #! Clean the data repo
    file.remove(list.files('./data/', pattern = '*.RData' ,full.names = T))
    
    #! metadata bank definition 
    bank <- list()
    
    #! bank save 
    save(bank,file = './data/bank.RData') 
    
    #! reload everything
    InitFunction()
    
  }
  else stop('Bank already exists!! (Danger)')  
}


#' Write data into metadata bank
#'
#' Write data into metadata bank : sensor or metadata.
#' 
#' @param uuid (uuid-char) uuid of the data
#' @param metadata (list) list of new metadata (or update)  
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' WriteMetadataBank()
#' }
#' 
#' @seealso \code{\link{NewMetadataBank}, 
#' \link{DeleteMetadataBank}, \link{ExistMetadataBank}}
#' \link{GetInfoMetadata}
#' 
WriteMetadataBank = function(uuid=NULL,metadata=NULL){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Uuid is mandatory
  if (is.null(uuid)) stop("You must give an uuid to write into the bank")
  
  #! Test if uuid exist (if not, creation)
  if (!(uuid %in% names(.rLE2P$bank))) .rLE2P$bank[[uuid]]=list()
  
  #! Insert metadata into the bank
  if (!(is.null(metadata) & !(length(metadata)==0))){
    
    #! Metadata names
    metadataNames <- names(metadata)
    
    #! list of existing metadata (the once who need update)
    metadataExists <- metadataNames %in% names(.rLE2P$bank[[uuid]])
    
    if(any(metadataExists)){
      #! Update existing metadata 
      .rLE2P$bank[[uuid]][metadataNames[metadataExists]] <- metadata[metadataExists]
      
      #! Suppress existing metadata 
      metadata[metadataExists] <- NULL  
    }
    
    #! Add new metadata 
    .rLE2P$bank[[uuid]] <- c(.rLE2P$bank[[uuid]],metadata) 
    
    #! Add time of last update*
    .rLE2P$bank[[uuid]][['lastUpdate']] <- Sys.time() 
  }
  
  #! Bank saving 
  save(bank,file = './data/bank.RData', envir = .rLE2P)
  
}

#' Get a simple query from a metadata list
#'
#' Create a query based on a given metadata list. 
#' (Note that the function ignore the 'lastUpdate' metadata)
#' 
#' @param metadataList (list) a list containing the metadata for a captor
#'
#' @return simpleQuery (char) a basic query
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' metadataList <- list(name = "FG", dataType = "xts")
#' simpleQuery <- queryFromCaptorMetadata(metadataList)
#' GetDataListFromQuery(logicalQuery = simpleQuery, eval = TRUE)
#' ## If you need to add a condition :
#' otherQuery <- paste0(c(simpleQuery, "idCampaign > 4"), collapse = " & ")
#' GetDataListFromQuery(logicalQuery = otherQuery, eval = TRUE)
#' }
#' 
#' @seealso \code{\link{NewMetadataBank}, \link{WriteMetadataBank},
#' \link{DeleteMetadataBank},  \link{GetInfoMetadata}, \link{ExistMetadataBank}}
#' 
GetQueryFromMetadataList = function(metadataList){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Return NULL if metadataList is not a list
  if (!is.list(metadataList)) return(NULL)
  
  #! Surround the character classed values of the metadatalist by char speficic marks
  bool <- lapply(metadataList, is.character)==TRUE
  metadataList[bool] <- paste0("'", metadataList[bool], "'")
  
  #! Create the query to return
  simpleQuery <- paste(paste(names(metadataList), metadataList, sep = '=='), collapse = ' & ')
  return(simpleQuery)
}

#' Get list of UUID data key with a query 
#'
#' Get the list of uuid (names of datafile) from a logical query 
#' on metadata.  
#' 
#' @param logicalQuery (char) Logical query on metadata (see examples)
#' @param eval (boolean) Eval the R expression 
#' @param contain (char vector)
#' @param restrict (char vector)
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' GetUuidFromQuery(logicalQuery = dataName=="FG" & dataType=="raw")
#' }
#' 
#' @seealso \code{\link{NewMetadataBank}, \link{WriteMetadataBank},
#' \link{DeleteMetadataBank}, \link{ExistMetadataBank}}
#' \link{GetInfoMetadata}, 
#' 
GetUuidFromQuery = function(logicalQuery=TRUE,eval=FALSE,contain=NULL,restrict=NULL){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Test if the bank is new  
  if (length(.rLE2P$bank)==0) return(NULL)
  
  #! Element of a list and a query about these list
  if (!eval)
    logicalQuery <- substitute(logicalQuery)
  else 
    logicalQuery <- parse(text = logicalQuery)
  result <- sapply(.rLE2P$bank,function(ele){
    if (!is.null(contain) & !all(contain %in% names(ele))) return(FALSE)
    if (!is.null(restrict) & !all(names(ele) %in% restrict)) return(FALSE)
    myEnv <- new.env(parent = baseenv())
    for (v in 1:length(ele)) assign(names(ele)[v], ele[[v]], envir = myEnv)
    tryCatch(eval(logicalQuery,envir = myEnv), error=function(e) {return(FALSE)})
  })
  
  if (any(result))
    return(names(result)[result])
  return(NULL)
}


#' Get list of UUID data key with a query and a data choices
#'
#' Get the list of uuid (names of datafile) from a logical query 
#' on metadata with a selection on transaction and data name.  
#'
#' @param logicalQuery (char) Logical query on metadata (see examples)
#'
#' @return Char list of uuid.
#' @export
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' GetUuidFromQueryDataSelect(logicalQuery = dataName=="FG" & dataType=="raw")
#' }
#' 
GetUuidFromQueryDataSelect <- function(logicalQuery){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Execute Query and ask to user
  logicalQuery <-deparse(substitute(logicalQuery))
  possibleUuid <- GetUuidFromQuery(logicalQuery,eval = TRUE)
  possibleUuidInfo <- GetMetadataFromUuid(possibleUuid,c('dataName','idTransaction','transactionName'),simplify = T)
  transactionNameSelection <- select.list(choices = unique(possibleUuidInfo$transactionName), graphics = T)
  bool <- possibleUuidInfo$transactionName == transactionNameSelection
  dataNameSelection <- select.list(choices = possibleUuidInfo$dataName[bool], multiple = T, graphics = T)
  bool <- bool & possibleUuidInfo$dataName %in% dataNameSelection
  return(rownames(possibleUuidInfo)[bool])
}


#' Delete data or meta into metadata bank 
#'
#' Delete a data metadata set of a particular uuid. If user give a list
#' of metadata name, it suppress just those metadata. 
#' 
#' @param uuid (uuid-char) uuid of the data
#' @param metadata (char-vector) list of metadata name
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' DeleteMetadataBank()
#' }
#' 
#' @seealso \code{\link{NewMetadataBank}, \link{WriteMetadataBank},
#'  \link{ExistMetadataBank}}
#' \link{GetInfoMetadata}, 
#' 
DeleteMetadataBank = function(uuid=NULL,metadata=NULL){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Uuid is mandatory
  if (is.null(uuid)) stop("You must give an uuid to delete into the bank.
                          If you want to delete all, use NewMetadataBank()
                          with reset = TRUE")
  
  #! Delete metadata into the bank
  if (!is.null(metadata) & length(metadata)>0)
    .rLE2P$bank[[uuid]][metadata]=NULL
  else 
    .rLE2P$bank[[uuid]]=NULL
  
  #! Bank saving 
  save(bank,file = './data/bank.RData', envir = .rLE2P)
  
}


#'
#' Get the list of all taken value of metadata. Plus you can have the list of metadata name.
#' 
#' @param uuid (vector char) One or a list of uuid of the data. If Null, get all uuid into the bank.
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' GetInfoMetadata()
#' }
#' 
#' @seealso \code{\link{NewMetadataBank}, \link{WriteMetadataBank},
#'  \link{DeleteMetadataBank},
#' \link{ExistMetadataBank}}
#' 
GetInfoMetadata = function(uuid=NULL){
  
  #! Test rLE2P context
  .IsContextSet()
  
  if(is.null(uuid))
    uuid <- names(.rLE2P$bank)
  
  #! Return result
  return(apply(GetMetadataFromUuid(uuid,simplify = T),2,unique))

}


#' Get metadata from an uuid. Metatdata selection effective.
#' 
#' From a list of uuid and metadata name, get all metadata values. 
#'
#' @param uuid (char vector) list of uuid
#' @param metadata  (char vector) list of meta name
#' @param simplify (boolean) TRUE if return a data.frame
#'
#' @return list or data.frame
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' GetMetadataFromUuid()
#' }
#' 
GetMetadataFromUuid <- function(uuid=NULL, metadata=NULL, simplify = FALSE ){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Return result
  if (is.null(uuid))  return(NULL)
  if (is.null(metadata)) 
    result <- .rLE2P$bank[uuid]
  else if (length(metadata>1))
    result <- lapply(.rLE2P$bank[uuid],function(ele,metadata){ele[metadata]},metadata=metadata)
  else 
    result <-lapply(.rLE2P$bank[uuid],function(ele,metadata){ele[[metadata]]},metadata=metadata) 
  if(simplify){
    options(stringsAsFactors = F)
    result <- do.call(rbind.data.frame, result)
  }
  return(result)
}

#' Existence test of metadata bank
#'
#' Test existence of the file bank.RData.
#' 
#' @return booelan
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'    ExistMetadataBank()
#' }
#' 
#' @seealso \code{\link{NewMetadataBank}, \link{WriteMetadataBank},
#' \link{DeleteMetadataBank}, \link{GetInfoMetadata}}
#' 
ExistMetadataBank = function(){
  danger <- exists(".rLE2P$bank") | file.exists('./data/bank.RData')
  return(danger)
}