#' Execute HCPC on local data 
#'
#' Allow to execute a clustering on local daily data 
#' 
#' @param nb.clust (Int) If 0, the tree is cut at the level the user 
#' clicks on. If -1, the tree is automatically cut at the suggested level 
#' (see details). If a (positive) integer, the tree is cut with nb.cluters 
#' clusters.
#' @param nb.par (Int) The number of edited paragons.
#' @param graph (boolean) TRUE if you want to display plot. 
#' @param listUuid (uuid-char-vector) Vector of the list of uuid to cluster.
#' @param export (boolean) TRUE if you want to save the results.
#' @param factoShiny (boolean) TRUE for use factoshiny.
#'
#' @return NULL
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'    ExecuteHCPC()
#' }
#'
ExecuteHCPC = function(nb.clust=-1,nb.par=5,graph=FALSE,listUuid=NULL,export=FALSE,factoShiny=TRUE){
  
  #! Selection of dataset (TO IMPROVE!!)
  if (is.null(listUuid))
    listUuid <- select.list(GetUuidFromQuery(dataType=='data.table'),multiple = F,graphics = T)
  
  #! Load dataset (TO IMPROVE : verify if we can concat datas)
  load(paste0("./data/",listUuid,'.RData'))
  
  #! HCPC execution
  analyse <- PCA(dT,ncp=30,graph=FALSE)
  if (factoShiny)
    resHCPC <- HCPCshiny(analyse)
  else
    resHCPC <- HCPC(
      analyse,
      nb.clust = nb.clust,
      nb.par = nb.par,
      graph = FALSE,
      graph.scale = "inertia"
    )
  
  #! Export the dataSet in csv format
  if (export){
    xSet       <- cbind(origin,date,resHCPC$data.clust$clust,data)  
    myjson     <- toJSON(GetInfoMetadata(uuid = listUuid),pretty = T)
    uuidExport <- UUIDgenerate(use.time = T)
    jsonFileName <- paste0('./data/',uuidExport,'.json')
    csvFileName  <- paste0('./data/',uuidExport,'.csv') 
    write(myjson,file = jsonFileName)
    write.csv(x = xSet,file = csvFileName ,row.names = F)
    message("Two file created in data directory :")
    message("  metadata : ",jsonFileName)
    message("  data     : ",csvFileName)
  } 
  
  #! Graph plot
  if (graph){
    plot.HCPC(resHCPC,choice="tree",title="Dendogram")  
    plot.HCPC(resHCPC,choice="bar",title="Inertia Gain")  
    plot.HCPC(resHCPC,choice="map",title="Principal Component Map")  
  }
  
  return(list(resHCPC = resHCPC,
              listUuid = listUuid))
}