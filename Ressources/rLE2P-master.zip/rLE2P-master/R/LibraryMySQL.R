#' RCI-GS MySQL Database Connection
#'
#' Open a connection to a MySQL Database. If no parameter is given,
#' the function will read connection parameter into the properties
#' file : properties.json.
#' 
#' @param host (char) server adress
#' @param user (char) login
#' @param password (char) password
#' @param dbname (char) name of database
#'
#' @return An object that extends \code{\link[DBI]{DBIConnection-class}} in a database-specific manner.
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' con <- BddConnection()
#' }
#' 
#' @seealso \code{\link{SendQuery}}
#' 
BddConnection=function(host=NULL,user=NULL,password=NULL,dbname=NULL){
  
  #! Configuration 
  if (is.null(host)) host <- Sys.getenv("rLE2P_mysql_host")
  if (is.null(user)) user <- Sys.getenv("rLE2P_mysql_user")
  if (is.null(password)) password <- Sys.getenv("rLE2P_mysql_password")
  if (is.null(dbname)) dbname <- Sys.getenv("rLE2P_mysql_dbname")
  
  #! Connection
  drv <- dbDriver("MySQL")
  con <- dbConnect(drv, user=user, password=password, dbname=dbname, host=host)
  return(con)
}


#' Send Query
#'
#' Send the given query and return the result set.
#'
#' @param query (char) A MySQL Query 
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' result <- SendQuery(query = 'SELECT * FROM data WHERE DATE(Date)="2012-05-05"')
#' }
#' 
#' @seealso \code{\link{GetListIdCampaign},\link{GetIdCampaign}}
#' 
SendQuery=function(query=NULL){
  con    <- BddConnection()
  res    <- dbSendQuery(con,query)
  result <- fetch(res, n = -1)
  dbClearResult(res)
  dbDisconnect(con)
  return(result)
}


#' Get Id Campaign
#'
#' Return selected Id Campaign
#'
#' @param all (bool) Retrun All Campaign if true
#' @param details (bool) Give boundary date in data for the selection 
#'
#' @return none
#' @export 
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' idCampaign <- GetIdCampaign()
#' }
#' 
#' @seealso \code{\link{GetListIdCampaign},\link{SendQuery}}
#' 
GetIdCampaign=function(all=FALSE,details=FALSE){
  
  #! Get list of Campaign
  if (details) query <- "call list_campaign_minmaxdate()"
  else query <- "call list_campaign()"
  result <- SendQuery(query)
  
  #! User choose
  if (!all){
    listChoices <- paste(result$Id_Campaign,result$Loc_Name,sep=' - ')
    choice <- select.list(listChoices, preselect = NULL,
                          title = "Campaign Choice", multiple = TRUE,
                          graphics = TRUE)
    result <- result[listChoices %in% choice,]
  }
  
  #! Create un char with campaign and locality
  campaignLocation <- paste(result$Id_Campaign,result$Loc_Name,sep='-')
  result <- cbind(result,campaignLocation,stringsAsFactors = FALSE)
  
  return(result)
}


#' Get the List of Id Campaign
#'
#' Return selected Id Campaign
#'
#' @param details (bool) Give boundary date in data for the selection 
#'
#' @return none
#' @export
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr} 
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' listCampaign <- GetListIdCampaign()
#' }
#' 
#' @seealso \code{\link{GetIdCampaign},\link{SendQuery}}
#' 
GetListIdCampaign=function(details=FALSE){
  
  #! Get list of Campaign
  if (details) query <- "call list_campaign_minmaxdate()"
  else query <- "call list_campaign()"
  result <- as.data.frame(SendQuery(query))
  
  #! Create un char with campaign and locality
  campaignLocation <- paste(result$Id_Campaign,result$Loc_Name,sep='-')
  result <- cbind(result,campaignLocation,stringsAsFactors = FALSE)
  
  return(result)
}