#' Plot graph of RCIGS campaign (dates)   
#'
#' Plot min and max of date for each campaign.
#' 
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' PlotListCampaignMinMaxDate()
#' }
#' 
PlotListCampaignMinMaxDate = function(){
  
  #! Data loading from the database  
  query <- "CALL list_campaign_minmaxdate();";
  data  <- SendQuery(query = query)
  
  #! set up the plot region
  sites   <- unique(data$Loc_Name)
  n       <- length(sites)
  palette <- rainbow(nrow(data), start=.7,end=.1)
  data$min_date <- as.POSIXct(data$min_date)
  data$max_date <- as.POSIXct(data$max_date)
  
  #! Initial plot (empty frame)
  plot( x = c(min(data$min_date), max(data$max_date)), 
        y = c(0,n), 
        type = "n",
        main = "Measurement campaign list",
        ylab='',
        xlab='Time')
  
  #! Plot each campaign
  for (i in 1:nrow(data)){
    siteNum <- which(data$Loc_Name[i]==sites)
    dateMoy <- min(data$min_date[i])+(max(data$max_date[i])-min(data$min_date[i]))/2
    rect(xleft   = min(data$min_date[i]),
         xright  = max(data$max_date[i]),
         ybottom = siteNum-1,
         ytop    = siteNum, 
         col     = palette[i])
    text(x = dateMoy,
         y = siteNum-0.5,
         col ='white',
         label = data$Id_Campaign[i])
  }
  
  #! Label 
  for (site in sites){
    siteNum <- which(site == sites)
    text(x = min(data$min_date)+10^7,
         y = siteNum-0.5,
         col = 1,
         label = site)
  }
}