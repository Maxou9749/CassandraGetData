#' Launch bankGraph in the default browser
#' 
#' Shiny App to visualise data from rLE2P database
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' if (interactive()) {
#'   BankGraph()
#' }
#' @export
#' 
BankGraph <- function() {
  appDir <- system.file("bankGraph", package = "rLE2P")
  if (appDir == "") {
    stop("Could not find example directory. Try re-installing `mypackage`.", call. = FALSE)
  }
  runApp(appDir, display.mode = "normal")
}

#' Launch CassandraGraph in the default browser
#' 
#' Shiny App to visualise data from Cassandra
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' if (interactive()) {
#'   CassandraGraph()
#' }
#' @export
#' 
CassandraGraph <- function() {
  appDir <- system.file("cassandraGraph", package = "rLE2P")
  if (appDir == "") {
    stop("Could not find example directory. Try re-installing `mypackage`.", call. = FALSE)
  }
  runApp(appDir, display.mode = "normal")
}

#' Launch CassandraMap in the default browser
#' 
#' Shiny App to visualise data from Cassandra on a map
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' if (interactive()) {
#'   CassandraMap()
#' }
#' @export
#' 
CassandraMap <- function() {
  appDir <- system.file("cassandraMap", package = "rLE2P")
  if (appDir == "") {
    stop("Could not find example directory. Try re-installing `mypackage`.", call. = FALSE)
  }
  runApp(appDir, display.mode = "normal")
}

#' Launch CassandraNa in the default browser
#' 
#' Shiny App to visualise missing data from Cassandra
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' if (interactive()) {
#'   CassandraNa()
#' }
#' @export
#' 
CassandraNa <- function() {
  appDir <- system.file("cassandraNa", package = "rLE2P")
  if (appDir == "") {
    stop("Could not find example directory. Try re-installing `mypackage`.", call. = FALSE)
  }
  runApp(appDir, display.mode = "normal")
}


#' Launch rEnvironUpdate in the default browser
#' 
#' Shiny App to modify Renviron properties : properties to acces databases. 
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' if (interactive()) {
#'   REnvironUpdate()
#' }
#' @export
#' 
REnvironUpdate <- function() {
  appDir <- system.file("rEnvironUpdate", package = "rLE2P")
  if (appDir == "") {
    stop("Could not find example directory. Try re-installing `mypackage`.", call. = FALSE)
  }
  runApp(appDir, display.mode = "normal")
}