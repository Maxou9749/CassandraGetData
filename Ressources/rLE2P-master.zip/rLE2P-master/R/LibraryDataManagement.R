#' Local database Update
#'
#' Update the R local database from RCI-GS MySQL Database.
#'
#' @param all (bool) Update all data if true
#' @param campaignLocation (char) The campaign location choosen
#' @param captor (char) The captor choosen
#'
#' @return none
#' @export
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Pauline Mialhe, \email{pauline.mialhe@@univ-reunion.fr}
#' 
#' @seealso \code{
#'   \link{CreateDailyTable}
#' }
#' 
RcigsUpdateLocalDatabase = function(all=FALSE,campaignLocation=NULL,captor=NULL){ 
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! Get Id campaign 
  if (is.null(campaignLocation))
    idCampaign <- GetIdCampaign(all=all)
  else{
    idCampaign <- GetIdCampaign(all= T)
    idCampaign <- idCampaign[idCampaign$campaignLocation %in% campaignLocation,]
  }
  
  #! Captor Selection 
  if (is.logical(captor)){
    if (captor){
      listCaptor <- c("FG","FD","Text","Tdl","Tcab","RH","WS","WD","Patm","Rain") 
      captor     <- select.list(listCaptor,multiple = TRUE,graphics = TRUE )  
    }
    else captor <- NULL
  }
  
  #! For each campaign, 
  for (index in 1:nrow(idCampaign)){
    
    #! Get all dataset from campaign 
    campaign  <- idCampaign$Id_Campaign[index]
    if (is.null(captor))
      query <- paste0("Call list_data_from_campaign(",campaign,")")
    else 
      query <- paste0("SELECT Date,",paste(captor,collapse = ',')," FROM data_cleaned WHERE Id_Campaign=",campaign," ORDER BY Date") 
    resultSet <- SendQuery(query)
    
    #! Time Changement
    resultSet$Date=as.POSIXct(resultSet$Date)
    resultSet=resultSet[!duplicated(resultSet[,1]),] #! delete all double entry
    
    #! Error Codage Update (values : -33, - 34, ...)
    resultSet[resultSet<0]=NA
    
    #! Save data 
    for (col in names(resultSet)[-1]){
      
      #! Transform data to xts
      Xt <- xts(resultSet[[col]], order.by = resultSet$Date)
      names(Xt) <- "values"
      infoPeriod <- periodicity(Xt)
      
      #! Metadata generation
      captorMetadata <- list(dataName         = col,
                             idTransaction    = paste('MySQL', campaign),
                             transactionName  = paste('MySQL',idCampaign$campaignLocation[index]), 
                             idCampaign       = campaign, 
                             dataDimension    = 1, 
                             dataType         = 'xts', 
                             timeStart        = infoPeriod$start, 
                             timeEnd          = infoPeriod$end,
                             timeScale        = infoPeriod$scale,
                             location         = idCampaign$Loc_Name[index],
                             campaignLocation = idCampaign$campaignLocation[index])
      
      #! List the mutable metadata from the list defined just above
      mutableMetadata <- c('timeStart', 'timeEnd')
      
      #! Control if data exist in local database for update else a new uuid is generated
      query <- GetQueryFromMetadataList(captorMetadata[!(names(captorMetadata) %in% mutableMetadata)])
      uuid <- GetUuidFromQuery(logicalQuery = query, eval = T, contain  = mutableMetadata)
      if (is.null(uuid)) 
        uuid <- UUIDgenerate(use.time = TRUE)
      
      #! Store metadata's uuid in the bank file
      WriteMetadataBank(uuid = uuid, metadata = captorMetadata)
      
      #! Data saving 
      fileName <- paste0('./data/',uuid,'.RData') 
      save(Xt,file = fileName)  
    }
  } 
}

#' Create daily table   
#'
#' Create daily table from 'xts' datas for a given (list of) uuid(s).
#' If the 'xts' datas needed does not exist, use \link{RcigsUpdateLocalDatabase} 
#' or \link{CassandraUpdateLocalDatabase} to create them.
#'
#' @param hourStart (num) The hour the data start each day
#' @param hourEnd (num)The hour the data end each day
#' @param uuidList (char vector) A list of uuid
#' @param maxMissingValue (num) The maximum missing value the day can contain
#'
#' @return none
#' @export
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @seealso \code{
#'   \link{RcigsUpdateLocalDatabase}
#' }
#' 
CreateDailyTable = function(hourStart=0, hourEnd=24, maxMissingValue=100, uuidList=NULL){
  
  #! Test rLE2P context
  .IsContextSet()
  
  #! if uuid null, transaction & sensor 
  if (is.null(uuidList))
    uuidList <- GetUuidFromQueryDataSelect(dataType=='xts' & timeScale=='minute')
  
  for(uid in uuidList){
    
    #! Some informations 
    uuidMetadata <- GetMetadataFromUuid(uuid = uid)[[uid]]
    message('## New Treatment')
    message('=> Local Data uuid  : ', uid)
    message('=> Transaction Name : ', uuidMetadata$transactionName)
    message('=> Transaction id   : ', uuidMetadata$idTransaction)
    message('=> Data Name        : ', uuidMetadata$dataName)
    message('=> Time Start       : ', uuidMetadata$timeStart)
    message('=> Time End         : ', uuidMetadata$timeEnd)
    message('=> Time Scale       : ', uuidMetadata$timeScale)
    
    #! load data
    load(paste0('./data/',uid,'.RData'))
    
    #! Reformat
    start <- as.POSIXct(format(index(first(Xt)),'%Y-%m-%d 00:00:00'))
    end   <- as.POSIXct(format(index(last(Xt)),'%Y-%m-%d 23:59:00'))
    fullTime <- xts(order.by=seq(start,end,"mins"))
    Xt <- merge.xts(Xt,fullTime) 
    fullDate <- as.Date(index(Xt[endpoints(Xt,on='days')]))
    if (hourStart<10) hourStartChar <- paste0('0',hourStart)
    else hourStartChar <- hourStart
    if (hourEnd<11) hourEndChar <- paste0('0',hourEnd-1)
    else hourEndChar <- hourEnd-1
    timeSelection <- paste0('T',hourStartChar,':00/T',hourEndChar,':59')
    dT   <- t(as.data.table(split.xts(Xt[timeSelection], f='days')))
    rownames(dT) <- as.character(fullDate)
    
    #! Days with to many NaN deletion 
    limit <- (hourEnd-hourStart)*60*maxMissingValue/100
    bool  <- apply(dT,1,function(a){sum(is.na(a))})>limit
    dT <- dT[!bool,]
    
    #! Control if data exist for update 
    query <- paste0("idTransaction=='", uuidMetadata$idTransaction, "' & dataName=='", uuidMetadata$dataName,
                    "' & hourStart==",hourStart," & hourEnd==",hourEnd," & maxMissingValue==",maxMissingValue,
                    " & dataType=='data.table'")
    uuid  <- GetUuidFromQuery(logicalQuery = query,eval=T)
    if (is.null(uuid)) {
      uuid <- UUIDgenerate(use.time = TRUE)
      message('==> New uuid for the *NEW* data : ', uuid)
    }
    
    #! metadata generation and 'bank' storage
    captorMetadata=list(dataName         = uuidMetadata$dataName, 
                        idTransaction    = uuidMetadata$idTransaction, 
                        transactionName  = uuidMetadata$transactionName,
                        dataDimension    = 2, 
                        dataType         = 'data.table', 
                        timeStart        = uuidMetadata$timeStart, 
                        timeEnd          = uuidMetadata$timeEnd, 
                        hourStart        = hourStart, 
                        hourEnd          = hourEnd, 
                        maxMissingValue  = maxMissingValue)
    WriteMetadataBank(uuid = uuid, metadata = captorMetadata )
    
    #! data saving 
    fileName=paste0('./data/',uuid,'.RData')
    save(dT,file = fileName)
    message('==> Full compute!')
    message('')
  }
}