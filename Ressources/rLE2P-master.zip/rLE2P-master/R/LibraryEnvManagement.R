#' Initialisation function
#'
#' Fonction ton initialize workspace, install library...
#'
#' @param directory (char) directory to init working path.
#'
#' @return none
#' @export
#'
#' @examples
#' \dontrun{
#' InitFunction()
#' }
#' 
InitFunction = function(directory='.'){
  
  #! Set directory
  setwd(dir = directory)
  
  #! Data directory generation 
  if (!dir.exists('./data/')) dir.create('./data/')
  if (!file.exists('./data/bank.RData')) NewMetadataBank()
  
  #! load bank in the rLE2P environment
  .rLE2P <<- new.env()
  load('./data/bank.RData', envir = .rLE2P)
}


#' Test is the rLE2P package context is set
#'
#' @return none 
#' @export
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' .IsContextSet()
#' }
#' 
.IsContextSet = function(){
  if (!exists(".rLE2P"))
    InitFunction(Sys.getenv("rLE2P_working_directory"))
  if (!is.environment(.rLE2P))
    stop("Don't use the variable called : .rLE2P\n",
         "It is an rLE2P system variable.")
}