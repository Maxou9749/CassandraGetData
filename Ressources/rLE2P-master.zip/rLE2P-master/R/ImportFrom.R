#! FULL IMPORT
#' @import RMySQL

#! IMPORT FROM
#' @importFrom data.table as.data.table
NULL
#' @importFrom DBI dbDriver dbConnect dbSendQuery dbClearResult dbDisconnect
NULL
#' @importFrom FactoMineR PCA HCPC plot.HCPC
NULL
#' @importFrom Factoshiny HCPCshiny
NULL
#' @importFrom graphics plot rect text
NULL
#' @importFrom grDevices rainbow
NULL
#' @importFrom jsonlite fromJSON toJSON
NULL
#' @importFrom RCurl postForm getForm
NULL
#' @importFrom RJDBC JDBC
NULL
#' @importFrom shiny runApp
NULL
#' @importFrom utils write.table select.list data write.csv
NULL
#' @importFrom uuid UUIDgenerate 
NULL
#' @importFrom xts xts periodicity first last endpoints merge.xts split.xts apply.daily
NULL
#' @importFrom zoo index
NULL