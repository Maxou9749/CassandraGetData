#' Get list of transaction into Cassandra
#'
#' This function return the datatable of transaction store in Cassandra. 
#'
#' @return A dataframe containing all the transaction datatable.
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'  trans <- cassGetTransactionList()
#' }
#' 
#' @seealso \code{
#'   \link{CassandraGetSensorFromTransaction},
#'   \link{CassandraGetData}, 
#'   \link{CassandraGetMetadata}
#' }
#' 
CassandraGetTransactionList = function(){
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost, 'rest/select/transaction', sep='/')
  userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    userpwd = userPwd,
    httpauth = 1L,
    postfields = '{}',
    httpheader = c('Content-Type' = 'application/json', Accept = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for all transactions
  transaction <- fromJSON(postForm(restAdr, .opts = restOpts))
  return(transaction$results)
}


#' Get list of sensor for a datawarehouse Transaction
#'
#' From an transaction id, you can get all the sensor names. 
#'
#' @param idTransaction (char) Id of the cassandra datawarehouse transaction,
#' @param rows (int) limit max for the result set.
#' @param onlyWithData (boolean) Request sensors only with data
#'
#' @return A characteur vector of the sensor into the transaction.
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'   CassandraGetSensorFromTransaction()
#' }
#' 
#' @seealso \code{\link{CassandraGetTransactionList},\link{CassandraGetData},
#' \link{CassandraGetMetadata}}
#' 
CassandraGetSensorFromTransaction = function(idTransaction = NULL, onlyWithData = FALSE, rows = 200){
  
  #! Test idTransaction
  if (is.null(idTransaction)) return(NULL)
  
  #! REST request
  if (onlyWithData)
    idTransaction <- paste0(idTransaction,'+AND+date_system_timeEnd:*')
  solrQuery <- paste0('q=transaction_id:',idTransaction,'&rows=',rows,'&fl=sensor_id&wt=json')
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/solr',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    userpwd = userPwd,
    httpauth = 1L,
    postfields = solrQuery,
    httpheader = c('Content-Type' = 'application/json', Accept = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for all transactions
  sensors <- fromJSON(postForm(restAdr, .opts = restOpts))$response$docs
  
  #! Remove the ghost captor
  sensors <- sensors[sensors!='ghost']
  return(sensors)
}


#' Get number of missing data per day
#'
#' From an transaction id and a sensor_id, you can get the number of missing
#' data beetween to date 
#'
#' @param idTransaction (char) Id of the cassandra datawarehouse transaction,
#' @param idSensor (char vector) Identifier/name of the sensor in Cassandra,
#' @param dateStart (date) Start date of the dataset ("YYYY-MM-DD"),
#' @param dateEnd (date) End date of the dataset ("YYYY-MM-DD").
#'
#' @return A list with the result.
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'   CassandraGetSensorNa()
#' }
#' 
CassandraGetSensorNa <- function(idTransaction, idSensor, dateStart = NULL, dateEnd = NULL){
  
  memTime <- Sys.time()
  
  cptMeta <- CassandraGetMetadata(idTransaction, idSensor)
  if (is.null(dateStart))
    dateStart <- as.Date(cptMeta$date_system_timeStart)
  if (is.null(dateEnd))
    dateEnd   <- as.Date(cptMeta$date_system_timeEnd)
  
  allDatesByMonths  <- c(seq.Date(dateStart, dateEnd, 'months'), dateEnd + 1) # + 1, it's not a month
  nADBM <- length(allDatesByMonths)
  
  fullData <- NULL
  for (i in 1:(nADBM-1)){
    timeStart <- paste(allDatesByMonths[i],'00:00:00')
    timeEnd <- paste(allDatesByMonths[i+1] - 1,'23:59:59') # - 1, for the whole month
    cassData <- CassandraGetData(idTransaction, idSensor, timeStart, timeEnd)
    if (is.null(cassData)) next() # if no data for this month
    fullData <- rbind(fullData, xts(cassData$value, as.POSIXct(cassData$date)))
  }
  
  p <- periodicity(fullData)
  pStart   <- as.POSIXct(paste(as.Date(p$start, tz = ""), "00:00:00"))
  fullDate <- seq.POSIXt(pStart, p$end, p$units)
  fullData <- cbind(xts(order.by = fullDate), fullData)
  
  result <- data.frame(apply.daily(fullData,function(d) sum(is.na(d))))
  thisDates <- as.Date(row.names(result))
  result = data.frame(date = thisDates, nNA = result[[1]])
  nYear <- length(unique(format(thisDates, '%Y')))
  
  return(list(
    nNaByDay = result, nYear = nYear, idTransaction = idTransaction, idSensor = idSensor,
    timeStart = pStart, timeEnd = p$end , now = Sys.time(), executionTime = Sys.time() - memTime
  ))
}

#' Get Data from Cassandra
#' 
#' Return a column of data from Cassandra database. You need to give in input
#' the two primary keys : idTransaction and idSensor.
#'
#' @param idTransaction (char string) Identifier of the transaction,
#' @param idSensor (char vector) Identifier/name of the sensor in Cassandra,
#' @param timeStart (timestamp) Start time of the dataset ("YYYY-MM-DD HH:MM:SS"),
#' @param timeEnd (timestamp) End time of the dataset ("YYYY-MM-DD HH:MM:SS").
#'
#' @return A matrix of 2 column, the first one is the date and the second one
#' is the values. 
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' CassandraGetData()
#' }
#' 
#' @seealso \code{
#'   \link{CassandraGetSensorFromTransaction},
#'   \link{CassandraGetTransactionList},
#'    \link{CassandraGetMetadata}
#' }
#' 
CassandraGetData = function(idTransaction = NULL, idSensor = NULL, timeStart = NULL, timeEnd = NULL){
  
  #! Answer is NULL if ids NULL 
  if (is.null(idTransaction) | is.null(idSensor)) return(NULL)
  
  #! Definition of postfiels for the Curl
  postfields <- paste0('"column":{"',idTransaction,'":["', paste(idSensor, collapse = '","'),'"]}')
  if (!is.null(timeStart)) 
    postfields <- paste0(postfields,',"timeStart":"',timeStart,'"')
  if (!is.null(timeEnd)) 
    postfields <- paste0(postfields,',"timeEnd":"',timeEnd,'"')
  postfields <- paste0('{',postfields,'}')
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/getSensorData',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    postfields = postfields,
    userpwd = userPwd,
    httpauth = 1L,
    httpheader = c('Content-Type' = 'application/json', Accept = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for the data
  X <- fromJSON(postForm(restAdr, .opts = restOpts))
  if (length(idSensor)==1) 
    return(X[[idTransaction]][[idSensor]])
  return(X[[idTransaction]])
}


#' Get Metadata from Cassandra
#' 
#' Return a list of metadata from Cassandra database. You need to give in input
#' the two primary keys : idTransaction and idSensor.
#'
#' @param idTransaction (char string) Identifier of the transaction,
#' @param idSensor (char string) Identifier/name of the sensor in Cassandra,
#' @param rows (int) limit max for the result set.
#' @param fl (char string) list of metadata separated by a coma
#'
#' @return A list of metadata.
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' CassandraGetMetadata()
#' }
#' 
#' @seealso \code{
#'   \link{CassandraGetSensorFromTransaction},
#'   \link{CassandraGetTransactionList},
#'   \link{CassandraGetData}
#' }
#' 
CassandraGetMetadata = function(idTransaction = NULL, idSensor = NULL, rows = 200, fl = NULL){
  
  #! Answer is NULL if ids NULL 
  if (is.null(idTransaction) | is.null(idSensor)) return(NULL)
  
  #! Allow sensor with blank
  idSensor <- gsub(pattern = " ", replacement = "+", x = idSensor)
  
  #! Definition of postfiels for the Curl
  solrQuery <- paste0('q=transaction_id:',idTransaction,'+AND+sensor_id:"',idSensor,
                      '"&rows=',rows,'&wt=json')
  if (!is.null(fl)) solrQuery <- paste0(solrQuery,'&fl=',fl)
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/solr',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    userpwd = userPwd,
    httpauth = 1L,
    postfields = solrQuery,
    httpheader = c('Content-Type' = 'application/json', Accept = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for all transactions
  metadata <- fromJSON(postForm(restAdr, .opts = restOpts))$response$docs
  return(metadata)
}

#' Local database Update from Cassandra 
#'
#' Update the R local database from GEOSUN Cassandra Database. You can update
#' multiple sensor from a Transaction 
#'
#' @param idTransaction (char) Identifier of the transaction,
#' @param idSensor (vector-char) Identifier/name of the sensor in Cassandra,
#'
#' @return Some uuid files in your ./data directory
#' @export
#' 
#' @examples
#' \dontrun{
#' CassandraUpdateLocalDatabase()
#' }
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' 
#' @seealso \code{
#'   \link{CassandraGetSensorFromTransaction},
#'   \link{CassandraGetTransactionList},
#'   \link{CassandraGetData}
#' }
#' 
CassandraUpdateLocalDatabase = function(idTransaction = NULL, idSensor = NULL){ 
  
  #! Get IdTransaction
  if (is.null(idTransaction)){
    transDetail <- CassandraGetTransactionList()
    transName   <- select.list(transDetail$name,multiple = FALSE,graphics = TRUE )
    idTransaction <- transDetail[transDetail$name %in% transName,"transaction_id"]
  }
  if (!exists("transName")){
    transDetail <- CassandraGetTransactionList()
    transName <- transDetail[transDetail$transaction_id %in% idTransaction,"name"]
  }
  
  #! Captor Selection 
  if (is.null(idSensor)){
    listSensor <- CassandraGetSensorFromTransaction(idTransaction = idTransaction)
    idSensor   <- select.list(listSensor, multiple = TRUE, graphics = TRUE )  
  }
  
  #! For each sensor, 
  for (idS in idSensor){
    
    #! Get all data and metatdata from sensor 
    resultSet <- CassandraGetData(idTransaction = idTransaction, idSensor = idS)
    if (is.null(resultSet)){
      message(paste("No data for the sensor", idS ,"in the transaction", idTransaction))
      next()
    }
    Xt <- xts(resultSet$value, order.by = as.POSIXct(resultSet$date))
    names(Xt) <- "values"
    metaSet <- CassandraGetMetadata(idTransaction = idTransaction, idSensor = idS)
    
    #! Save data 
    #! Control if data exist in local database for update 
    query=paste0("idTransaction==", idTransaction, " & dataName=='", idS,"' & dataType=='xts'")
    uuid <- GetUuidFromQuery(logicalQuery = query,eval = T)
    if (is.null(uuid)) 
      uuid <- UUIDgenerate(use.time = TRUE)
    
    #! metadata generation and 'bank' storage
    infoPeriod <- periodicity(Xt)
    captorMetadata <- list(
      dataName      = idS, 
      idTransaction = idTransaction,
      transactionName = transName,
      dataDimension = 1, 
      dataType      = 'xts', 
      timeStart     = infoPeriod$start, 
      timeEnd       = infoPeriod$end,
      timeScale     = infoPeriod$scale
    )
    WriteMetadataBank(uuid = uuid, metadata = captorMetadata )
    
    #! data saving 
    fileName=paste0('./data/',uuid,'.RData') 
    save(Xt,file = fileName)  
  }
}


#' Get all list of meta data model in Cassandra
#' 
#' Return a data.frame with all parameter and definition of metadata
#' model in Cassandra. 
#'
#' @return data.frame of meta types
#' @export
#'
#' @examples
#' \dontrun{
#' CassandraGetMetaTypesList()
#' }
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'   
CassandraGetMetaTypesList = function(){
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/select/meta_types',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    postfields = '{}',
    userpwd = userPwd,
    httpauth = 1L,
    httpheader = c('Content-Type' = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for all transactions
  metaTypes <- fromJSON(postForm(restAdr,.opts = restOpts))
  return(metaTypes$results)
}

#' Get the result of a Solr Query througt the Rest
#'
#' @param query a Solr query
#'
#' @return data.frame of meta types
#' @export
#'
#' @examples
#' \dontrun{
#' CassandraGetSolrQuery()
#' }
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'   
CassandraGetSolrQuery = function(query = 'q=*:*&wt=json'){
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/solr',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    postfields = query,
    userpwd = userPwd,
    httpauth = 1L,
    httpheader = c('Content-Type' = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for all transactions
  solr <- fromJSON(postForm(restAdr, .opts = restOpts))
  return(solr)
}

#' Insert a new metadata type in a category
#'
#' @param category (char) the name of the category
#' @param metaName (char) the name of the metadata
#' @param type (char) the type : "bool_","text_","double_","date_"
#'
#' @return TRUE if the insertion works. FALSE else. 
#' @export
#'
#' @examples
#' \dontrun{
#'   CassandraInsertMetaType()
#' }
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' 
CassandraInsertMetaType = function(category=NULL,metaName=NULL,type=NULL){
  
  #! Control category, metaName and type
  if (is.null(category)) stop("category can't be NULL.")
  if (is.null(metaName)) stop("metaName can't be NULL.")
  if (is.null(type)) stop("type can't be NULL.")
  if (!(type %in% c('double_','text_','bool_','date_')))
    stop("type must be in c('double_','text_','bool_','date_').")
  
  #! Build the postfields
  postfields <- paste0('{"compoundKey":{"category":"',category,
                       '","meta_name":"',metaName,
                       '"}, "type":"',type,'"}')
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/insert/meta_types',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  restOpts <- list(
    postfields = postfields,
    userpwd = userPwd,
    httpauth = 1L,
    httpheader = c('Content-Type' = 'application/json'),
    ssl.verifyhost = FALSE,
    ssl.verifypeer = FALSE
  )
  
  #! Ask rest service for all transactions
  isOk <- fromJSON(postForm(restAdr, .opts = restOpts))
  if(isOk$success)  return(TRUE)
  return(FALSE)
}

#' Insert metadata into Cassandra
#' 
#' You can insert some metadata to a sensor in Cassandra. You must respect  cassandra 
#' the metadata model. 
#'
#' @param idTransaction (char) The id of the transaction.
#' @param idSensor (char) The id of the sensor
#' @param metaList (list) a R list with the metadata
#' @param category (char) NOT WORKING precise the category if you want to work with 
#'
#' @return OK is the insert was OK
#' @export
#' 
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'   CassandraInsertMetadata()
#' }
#' 
CassandraInsertMetadata = function(idTransaction=NULL,idSensor=NULL,metaList=NULL,category=NULL){
  
  #### RESTE A FAIRE SI DOUBLE CATEGORIE
  
  #! Control idTransaction, metaName, idSensor
  if (is.null(idTransaction)) stop("idTransaction can't be NULL.")
  if (is.null(idSensor)) stop("idSensor can't be NULL.")
  if (is.null(metaList) & !is.list(metaList))
    stop("metaList can't be NULL and must be a list.")
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/update/meta_search/insert',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  postfields <- paste0('{"compoundKey":{"transaction_id":"',idTransaction,'","sensor_id":"',idSensor,'"},')
  
  #! Get metadata model to build meta name in cassandra
  metaTypes <- CassandraGetMetaTypesList()
  for (mLName in names(metaList)){
    bool <- metaTypes$compoundKey$meta_name %in% mLName
    n    <- sum(bool)
    if (n==1){
      
      #! build meta name for mLName
      metaParam <- metaTypes[bool,]
      
      #! If bool_
      if (metaParam$typ=='bool_'){
        if (is.logical(metaList[[mLName]])){
          metaCassName <- paste0(metaParam$typ,metaParam$compoundKey$category,'_',metaParam$compoundKey$meta_name)
          if (metaList[[mLName]])
            value <- "true"
          else 
            value <- "false"
          thisPostfields <- paste0(postfields,'"',metaParam$typ,'":{"',metaCassName,'":',value,'}}')
        }
        else 
          print(paste(mLName,"must be a logical value."))
      }
      
      #! If text_
      if (metaParam$typ=='text_'){
        if (is.character(metaList[[mLName]])){
          metaCassName <- paste0(metaParam$typ,metaParam$compoundKey$category,'_',metaParam$compoundKey$meta_name)
          thisPostfields <- paste0(postfields,'"',metaParam$typ,'":{"',metaCassName,'":"',metaList[[mLName]],'"}}')
        }
        else 
          print(paste(mLName,"must be a character"))
      }
      
      #! If double_
      if (metaParam$typ=='double_'){
        if (is.numeric(metaList[[mLName]])){
          metaCassName <- paste0(metaParam$typ,metaParam$compoundKey$category,'_',metaParam$compoundKey$meta_name)
          thisPostfields <- paste0(postfields,'"',metaParam$typ,'":{"',metaCassName,'":',metaList[[mLName]],'}}')
        }
        else 
          print(paste(mLName,"must be a numeric value."))
      }
      
      #! If date_
      if (metaParam$typ=='date_'){
        metaCassName <- paste0(metaParam$typ,metaParam$compoundKey$category,'_',metaParam$compoundKey$meta_name)
        thisPostfields <- paste0(postfields,'"',metaParam$typ,'":{"',metaCassName,'":"',as.POSIXct(metaList[[mLName]]),'"}}')
      }
      
      restOpts <- list(
        postfields = thisPostfields,
        userpwd = userPwd,
        httpauth = 1L,
        httpheader = c('Content-Type' = 'application/json'),
        ssl.verifyhost = FALSE,
        ssl.verifypeer = FALSE
      )
      
      #! Ask rest service to insert the metadata
      isOk <- fromJSON(postForm(restAdr,.opts = restOpts))
    }
    else if (n>1) 
      print(paste('Please precise the category for the attribue',mLName))
    else 
      print(paste(mLName,"doesn't exists in the Cassandra Metadata Model"))
  }
  
  return(TRUE)  
}

#' Delete metadata into cassandra 
#'
#' @param idTransaction (char) The id of the transaction.
#' @param idSensor (char) The id of the sensor.
#' @param metaName (char vector) list of metaname to delete.
#' @param category (char) NOT WORKING precise the category if you want to work with.
#'
#' @return OK is the insert was OK
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#'   CassandraDeleteMetadata()
#' }
#' 
CassandraDeleteMetadata = function(idTransaction=NULL,idSensor=NULL,metaName=NULL,category=NULL){
  
  #! RESTE A FAIRE SI DOUBLE CATEGORIE
  
  #! Control idTransaction, metaName, idSensor
  if (is.null(idTransaction)) stop("idTransaction can't be NULL.")
  if (is.null(idSensor)) stop("idSensor can't be NULL.")
  if (is.null(metaName)) stop("metaName can't be NULL.")
  
  #! load rest service host for cassandra
  restHost <- Sys.getenv("rLE2P_restHost")
  restAdr  <- paste(restHost,'rest/update/meta_search/delete',sep='/')
  userPwd  <- userPwd  <- Sys.getenv("rLE2P_restUserPwd")
  postfields <- paste0('{"compoundKey":{"transaction_id":"',idTransaction,'","sensor_id":"',idSensor,'"},')
  
  #! Get metadata model to build meta name in cassandra
  metaTypes <- CassandraGetMetaTypesList()
  for (mN in metaName){
    bool <- metaTypes$compoundKey$meta_name %in% mN
    n    <- sum(bool)
    if (n==1){
      
      #! build meta name for mN
      metaParam    <- metaTypes[bool,]
      metaCassName <- paste0(metaParam$typ,metaParam$compoundKey$category,'_',metaParam$compoundKey$meta_name)
      thisPostfields <- paste0(postfields,'"',metaParam$typ,'":{"',metaCassName,'":""}}')
      restOpts <- list(
        postfields = thisPostfields,
        userpwd = userPwd,
        httpauth = 1L,
        httpheader = c('Content-Type' = 'application/json'),
        ssl.verifyhost = FALSE,
        ssl.verifypeer = FALSE
      )
      
      #! Ask rest service to delete the metadata
      isOk <- fromJSON(postForm(restAdr, .opts = restOpts))
    }
    else if (n>1) 
      print(paste('Please precise the category for the attribue',mN))
    else 
      print(paste(mN,"doesn't exists in the Cassandra Metadata Model"))
  }
  
  return(TRUE)  
}


#' RCassandra JDBC Database Connection
#'
#' Open a connection to a Cassandra Database. 
#' 
#' @return An object that extends \code{\link[DBI]{DBIConnection-class}} in a database-specific manner.
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' con <- CassandraJDBCConnection()
#' }
#' 
#' @seealso \code{\link{CassandraSendQuery}}
#' 
CassandraJDBCConnection=function(){
  
  if (!exists("drv")){
    javaDir <- system.file("java", package = "rLE2P")
    jdbcDriverClass <- "org.apache.cassandra.cql.jdbc.CassandraDriver"
    jdbcClassPath   <- list.files(javaDir, pattern="jar$", full.names = T)
    drv <- JDBC(jdbcDriverClass, jdbcClassPath)
  }
  cassAdrConnector <- "jdbc:cassandra://10.82.64.101:9160/geosun?consistency=ONE"
  con <- dbConnect(drv, cassAdrConnector)
  return(con)
}

#' Cassandra Send Query
#'
#' Send the given query and return the result set.
#'
#' @param query (char) A MySQL Query 
#'
#' @return none
#' @export
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#'
#' @examples
#' \dontrun{
#' result <- CassandraSendQuery(query = 'SELECT * FROM data WHERE DATE(Date)="2012-05-05"')
#' }
#' 
CassandraSendQuery=function(query=NULL){
  con    <- CassandraJDBCConnection()
  res    <- dbSendQuery(con,query)
  result <- fetch(res, n = -1)
  dbClearResult(res)
  rJava::J("java.lang.Runtime")$getRuntime()$gc()
  dbDisconnect(con)
  return(result)
}

#' Cassandra Obtaint Prediction From XGBoost
#'
#' Allow to call the plumber REST API giving acces to xgboost prediction model  
#'
#' @param idTransaction (char) Id of the cassandra datawarehouse transaction, 
#' @param timeEnd (timestamp) The last known date 
#' @param horizon (int) Horizon of the prediction in mins
#' @param step (int) Step of needed prediction between timeEnd and (timeEnd + horizon)
#'
#' @export
#' @return A list containing the predicted values
#'
#' @author Mathieu Delsaut, \email{mathieu.delsaut@@univ-reunion.fr}
#' @author Claire Quatrehomme, \email{claire.quatrehomme@insa-lyon.fr}
#'
#' @examples
#' \dontrun{
#' result <- CassandraGetPrediction(idTransaction = '1465986423')
#' }
#' 
CassandraGetPrediction <- function(idTransaction = NULL, timeEnd = NULL, horizon = 60, step = 15){
  
  #! Control idTransaction
  if (is.null(idTransaction)) stop("idTransaction can't be NULL.")
  
  myArgs   <- as.list(environment(), all = TRUE)
  restHost <- Sys.getenv("rLE2P_predHost")
  restAdr  <- paste(restHost, 'prediction', sep = '/')
  prediction <- fromJSON(getForm(restAdr, .params = myArgs))
  return(prediction)
}
